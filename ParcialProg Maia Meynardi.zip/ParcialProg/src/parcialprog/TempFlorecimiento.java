package parcialprog;

public enum TempFlorecimiento {
    PRIMAVERA,
    VERANO,
    OTOÑO, 
    INVIERNO;
}
