
package parcialprog;


public interface Podable {
    public abstract void podar();
}
