package parcialprog;

/**
 *
 * @author Maia Meynardi
 */
public class Main {

 
    public static void main(String[] args) {
        JardinBotanico jardin = new JardinBotanico();
        try{
            
            jardin.agregarPlanta(new Arbol("Roble", "norte", "frio", 10));
            jardin.agregarPlanta(new Arbol("Roble", "norte", "frio", 10));
            jardin.agregarPlanta(new Flor("Margarita", "sur", "humedo", TempFlorecimiento.PRIMAVERA));
            jardin.agregarPlanta(new Arbusto("Coralillo", "este", "templado", 3));
            jardin.podarPlantas();
        }catch(IllegalArgumentException| NullPointerException | PlantaRepetidaException p ) {
            System.out.println(p.getMessage());
        }
        
      System.out.println("----------------");
        jardin.mostrarPlantas();
        
        
    }
    
}
