package parcialprog;


public class Arbusto extends Planta implements Podable {
    private int densidadFollaje;

    public Arbusto(String nombre, String ubicacion, String clima, int densidadFollaje) {
        super(nombre, ubicacion, clima);
        this.densidadFollaje = densidadFollaje;
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Densidad de follaje " + densidadFollaje + "]";
    }
    
    @Override
    public void podar(){
        System.out.println("Podando el arbusto: " + getNombre());
        
    }
    
    private void densidadFollaje(int densidad) {
        if (densidad < 1 || densidad > 10) {
            throw new IllegalArgumentException("Error. La densidad tiene que ser entre 1 y 10.");
        }
    }

}
