
package parcialprog;

public class Flor extends Planta {
    private TempFlorecimiento temporada;

    public Flor(String nombre, String ubicacion, String clima, TempFlorecimiento temporada) {
        super(nombre, ubicacion, clima);
        validarEnum(temporada);
        this.temporada = temporada;
    }

    @Override
    public String toString() {
        return super.toString() + ", Temporada de Florecimiento: " + temporada + "]";
    }
    
    protected final void validarEnum(Enum tipo){
        if(tipo == null){
            throw new NullPointerException("No se admite una temporada null.");
        }
    }
}
