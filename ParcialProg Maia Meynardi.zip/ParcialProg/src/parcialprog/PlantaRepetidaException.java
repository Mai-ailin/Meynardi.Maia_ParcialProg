package parcialprog;


public class PlantaRepetidaException extends RuntimeException {
    private static final String MESSAGE = "La planta ingresada esta en la lista en el Jardin.";
            
    public PlantaRepetidaException() {
        super(MESSAGE);
    }
}
