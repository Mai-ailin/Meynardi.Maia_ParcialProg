
package parcialprog;

import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {
    private List<Planta>plantas;

    public JardinBotanico() {
        plantas = new ArrayList<>();
    }
    
   public void podarPlantas() {
    for (Planta p : plantas) {
        if (p instanceof Podable po){
            po.podar();
        }else{
            System.out.println(p.getNombre() + " no requiere ser podado.");
        } 
           
    }}
   
   public void mostrarPlantas(){
        if (plantas.isEmpty()){
            System.out.println("No hay plantas en el Jardin.");
        }
        else{
            System.out.println("Plantas en el Jardin: ");
            for (Planta p : plantas) {
                System.out.println(p);
            }
        }
    }
   
    public void agregarPlanta(Planta planta){
        if (plantas.contains(planta)){
            throw new PlantaRepetidaException();
        }
        plantas.add(planta);
        System.out.println("Planta agregada: " + planta.getNombre());
    }
}
