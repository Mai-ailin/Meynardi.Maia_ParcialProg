package parcialprog;

import java.util.Objects;

public abstract class Planta {
    private String nombre;
    private String ubicacion;
    private String clima;
    
    public Planta(String nombre, String ubicacion, String clima){
        validarString(nombre);
        validarString(ubicacion);
        validarString(clima);
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
             
    }

    @Override
    public String toString() {
        return "Planta[" + "nombre= " + nombre + ", ubicacion= " + ubicacion + ", clima= " + clima;
    }
    
    
    public String getNombre() {
        return nombre;
    }
    
  
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Planta other = (Planta) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return Objects.equals(this.ubicacion, other.ubicacion);
    }
    
     @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
        
    }
    private void validarString(String str) {
        if (str == null || str.isEmpty()) {
            throw new IllegalArgumentException("El (nombre, ubicacion y clima) no puede ser nulo o vacio.");
        }
    }

}

   

