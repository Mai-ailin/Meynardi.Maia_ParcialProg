package parcialprog;

public class Arbol extends Planta implements Podable {
    private double alturaMaxima;

    public Arbol(String nombre, String ubicacion, String clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        validarAltura(alturaMaxima);
        this.alturaMaxima = alturaMaxima;
    }
    
    @Override
    public String toString() {
        return super.toString() + ", Altura Maxima: " + alturaMaxima + "metros]";
    }
    
    @Override
   public void podar(){
        System.out.println("Podando el arbol: " + getNombre());
    }
    
   private void validarAltura(double altura) {
        if (altura < 0) {
            throw new IllegalArgumentException("Error. La altura debe ser mayor a 0.");
        }
    }
    
    
    
    
}
